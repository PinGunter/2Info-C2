#ifndef MODELOS_BELKAN
#define  MODELOS_BELKAN

#include "modelos/aldeano/aldeano.hpp"
#include "modelos/jugador/jugador3d.hpp"
#include "modelos/arbol/arbol.hpp"
#include "modelos/item/item.hpp"

#endif
