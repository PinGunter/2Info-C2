INSERT INTO pieza VALUES ('P1', 'Tuerca', 'Gris', 2.5, 'Madrid');
INSERT INTO pieza VALUES ('P2', 'Tornillo', 'Rojo', 1.25, 'Paris');
INSERT INTO pieza VALUES ('P3', 'Arandela', 'Blanco', 3, 'Londres');
INSERT INTO pieza VALUES ('P4', 'Clavo', 'Gris', 5.5, 'Lisboa');
INSERT INTO pieza VALUES ('P5', 'Alcayata', 'Blanco', 10, 'Roma');

SELECT * FROM pieza;