INSERT INTO ventas SELECT * FROM opc.ventas;

SELECT * FROM ventas;