INSERT INTO proyecto VALUES('J1', 'Proyecto 1', 'Londres');
INSERT INTO proyecto VALUES('J2', 'Proyecto 2', 'Londres');
INSERT INTO proyecto VALUES('J3', 'Proyecto 3', 'Paris');
INSERT INTO proyecto VALUES('J4', 'Proyecto 4', 'Roma');

SELECT * FROM proyecto;