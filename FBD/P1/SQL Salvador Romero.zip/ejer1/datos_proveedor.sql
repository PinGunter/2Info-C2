INSERT INTO proveedor VALUES ('S1', 2, 'Madrid', 'Jose Fernandez');
INSERT INTO proveedor VALUES ('S2', 1, 'Londres', 'Manuel Vidal');
INSERT INTO proveedor VALUES ('S3', 3, 'Lisboa', 'Luisa Gomez');
INSERT INTO proveedor VALUES ('S4', 4, 'Paris', 'Pedro Sanchez');
INSERT INTO proveedor VALUES ('S5', 5, 'Roma', 'Maria Reyes');

select * from proveedor;